import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { users, game_sessions, codex_entries, type User } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: Partial<User> & { openId: string }): Promise<void> {
  const db = await getDb();
  if (!db) return;

  const values = {
    openId: user.openId,
    name: user.name ?? null,
    email: user.email ?? null,
    loginMethod: user.loginMethod ?? null,
    lastSignedIn: new Date(),
    role: (user.openId === ENV.ownerOpenId ? 'admin' : 'user') as 'admin' | 'user',
  };

  await db.insert(users).values(values).onDuplicateKeyUpdate({
    set: {
      name: values.name,
      email: values.email,
      lastSignedIn: values.lastSignedIn,
    },
  });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function saveGameSession(userId: number, chapter: string, progress: number, customization: any) {
  const db = await getDb();
  if (!db) return;
  await db.insert(game_sessions).values({
    userId,
    chapter,
    progress,
    customization,
  }).onDuplicateKeyUpdate({
    set: { chapter, progress, customization },
  });
}

export async function getGameSession(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(game_sessions).where(eq(game_sessions.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function discoverCodex(userId: number, entryKey: string) {
  const db = await getDb();
  if (!db) return;
  await db.insert(codex_entries).values({ userId, entryKey });
}

export async function getCodexEntries(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(codex_entries).where(eq(codex_entries.userId, userId));
}
