import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";
import * as db from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  game: router({
    saveSession: protectedProcedure
      .input(z.object({
        chapter: z.string(),
        progress: z.number(),
        customization: z.any(),
      }))
      .mutation(async ({ ctx, input }) => {
        await db.saveGameSession(ctx.user.id, input.chapter, input.progress, input.customization);
        return { success: true };
      }),
    getSession: protectedProcedure.query(async ({ ctx }) => {
      return db.getGameSession(ctx.user.id);
    }),
    discoverCodex: protectedProcedure
      .input(z.object({ entryKey: z.string() }))
      .mutation(async ({ ctx, input }) => {
        await db.discoverCodex(ctx.user.id, input.entryKey);
        return { success: true };
      }),
    getCodex: protectedProcedure.query(async ({ ctx }) => {
      return db.getCodexEntries(ctx.user.id);
    }),
    chatWithNpc: publicProcedure
      .input(z.object({
        npcId: z.string(),
        messages: z.array(z.object({ role: z.enum(["user", "npc"]), text: z.string() })),
        context: z.object({ chapter: z.string(), mission: z.string(), location: z.string(), locale: z.enum(["ar", "en"]) }).optional(),
      }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: `You are an NPC in the game "City Crime — The Threshold". Your ID is ${input.npcId}. The current chapter is ${input.context?.chapter ?? "chapter1"}; the current mission is ${input.context?.mission ?? "unknown"}; the player location is ${input.context?.location ?? "unknown"}. Respond in ${input.context?.locale === "ar" ? "Arabic" : "English"}. Keep responses short, immersive, and grounded in the current scene. Do not invent religious quotations or claim historical certainty.` },
            ...input.messages.map(m => ({ role: m.role === "user" ? "user" as const : "assistant" as const, content: m.text })),
          ],
        });
        return { text: response.choices[0].message.content ?? "" };
      }),
  }),
});

export type AppRouter = typeof appRouter;
