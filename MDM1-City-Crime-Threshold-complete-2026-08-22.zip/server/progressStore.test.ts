import { describe, expect, it } from "vitest";
import { normalizeGameProgress } from "../client/src/game/progressStore";

describe("game progress normalization", () => {
  it("deduplicates Codex evidence and preserves a valid resumable snapshot", () => {
    const progress = normalizeGameProgress({
      version: 1,
      chapter: "chapter4",
      customization: { character: "rose", carColor: "#20242b", carModel: "sedan" },
      locale: "ar",
      codex: ["threshold-evidence-chapter1", "threshold-evidence-chapter1", "threshold-evidence-chapter3"],
      updatedAt: 1,
    });
    expect(progress.chapter).toBe("chapter4");
    expect(progress.codex).toEqual(["threshold-evidence-chapter1", "threshold-evidence-chapter3"]);
  });
});
