import { describe, expect, it } from "vitest";
import { chapters, chapterOrder } from "../client/src/game/chapters";
import { chapterBackdrops } from "../client/src/game/chapterVisuals";

describe("City Crime chapter progression", () => {
  it("contains seven non-empty playable chapters", () => {
    expect(chapterOrder).toHaveLength(7);
    for (const id of chapterOrder) {
      const chapter = chapters[id];
      expect(chapter.mission.ar).not.toBe("");
      expect(chapter.mission.en).not.toBe("");
      expect(chapter.challenge.ar).not.toBe("");
      expect(chapter.challenge.en).not.toBe("");
      expect(chapter.architecture).toBeTruthy();
    }
  });

  it("keeps the final destination as the Mars decision", () => {
    expect(chapterOrder.at(-1)).toBe("chapter7");
    expect(chapters.chapter7.architecture).toBe("mars");
    expect(chapters.chapter7.title.en).toContain("MARS");
  });

  it("assigns a unique original cinematic backdrop to every chapter", () => {
    const assets = chapterOrder.map((id) => chapterBackdrops[id]);
    expect(assets).toHaveLength(7);
    expect(new Set(assets).size).toBe(7);
    for (const asset of assets) expect(asset).toMatch(/^\/manus-storage\/mdm1-chapter-\d{2}-[a-z-]+_[a-f0-9]+\.jpg$/);
  });
});
