import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const game_sessions = mysqlTable("game_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").references(() => users.id),
  chapter: varchar("chapter", { length: 32 }).notNull(),
  progress: int("progress").default(0).notNull(),
  customization: json("customization").notNull(),
  lastPlayedAt: timestamp("lastPlayedAt").defaultNow().onUpdateNow().notNull(),
});

export const codex_entries = mysqlTable("codex_entries", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").references(() => users.id),
  entryKey: varchar("entryKey", { length: 64 }).notNull(),
  discoveredAt: timestamp("discoveredAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type GameSession = typeof game_sessions.$inferSelect;
export type CodexEntry = typeof codex_entries.$inferSelect;
