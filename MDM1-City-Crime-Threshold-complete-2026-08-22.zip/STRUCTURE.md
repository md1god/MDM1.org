# البنية التقنية

> React هو الإطار، Babylon هو اللوحة، وقواعد اللعب هي عالم مستقل لا يعتمد على React.

| المسار | المسؤولية |
|---|---|
| `client/src/components/GameCanvas.tsx` | دورة حياة المحرك الآمنة، تغيير الحجم، وربط أحداث الحالة إلى React. |
| `client/src/components/GameHUD.tsx` | كل واجهة اللعب والتفضيلات واللمس؛ لا ينشئ مجسمات Babylon ولا يملك قواعد اللعبة. |
| `client/src/game/scene.ts` | إنشاء المحرك/المشهد وإرجاع `GameHandle` قابل للتفريغ. |
| `client/src/game/GameWorld.ts` | مالك المنطقة الحالية، اللاعب، الكاميرا، التفاعل، والانتقال. |
| `client/src/game/ChapterManager.ts` | تحميل/تفريغ الفصول وحفظ حالة التقدم. |
| `client/src/game/chapters/*` | منشئو المناطق المستقلة وبيانات المهام والتحديات. |
| `client/src/game/InputManager.ts` | تحويل لوحة المفاتيح/الماوس/اللمس إلى أفعال دلالية. |
| `client/src/game/QualityManager.ts` | كشف العتاد ومراقبة FPS وتطبيق إعدادات الرسم. |
| `client/src/game/PhysicsManager.ts` | Havok غير الحاجب ومسار الحركة الآمن البديل. |
| `client/src/game/EventBus.ts` | أحداث واضحة بين نواة اللعب وواجهة React. |
| `client/src/game/i18n.ts` | قواميس عربية/إنجليزية واختيار لغة المتصفح. |

## حالة اللعب

`boot → intro → chapter-1 → chapter-2 → … → chapter-7 → epilogue`

تنتقل الحالات فقط عبر `ChapterManager`. أما الحالات العرضية فهي: `onFoot`، `inVehicle`، `interacting`، `paused`. لا تتسرب أحداث Babylon إلى مكونات React؛ يقتصر التواصل على نموذج `GameUIState` قابل للنسخ.
