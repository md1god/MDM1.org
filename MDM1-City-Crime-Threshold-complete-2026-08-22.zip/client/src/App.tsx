/** «أثر العتبة»: طريق وحيد يضع Canvas اللعبة في كامل الشاشة ولا يحمّل أي واجهة صفحة مستقلة. */
import ErrorBoundary from "./components/ErrorBoundary";
import GameCanvas from "./components/GameCanvas";

export default function App() {
  return <ErrorBoundary><GameCanvas /></ErrorBoundary>;
}
