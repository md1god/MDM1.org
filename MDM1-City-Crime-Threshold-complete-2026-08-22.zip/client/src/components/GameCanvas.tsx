/**
 * «أثر العتبة»: React إطار الواجهة، Babylon مساحة اللعب. المحرك لا يُنشأ إلا مرة واحدة ويُفرغ كاملاً عند الإلغاء.
 */
import { useCallback, useEffect, useRef, useState } from "react";
import GameHUD from "@/components/GameHUD";
import { GameEventBus } from "@/game/EventBus";
import { createGameEngine, createGameScene, type GameHandle } from "@/game/scene";
import type { GameCommand, GameUIState } from "@/game/types";

const savedSessions = () => {
  try { return JSON.parse(localStorage.getItem("mdm1-city-crime-sessions") ?? "[]"); } catch { return []; }
};

const initialState: GameUIState = {
  mode: "loading", engineKind: "WebGL2", quality: "Medium", qualityAuto: true, fps: 0,
  loadingProgress: 0, loadingLabel: "", locale: navigator.language.toLowerCase().startsWith("ar") ? "ar" : "en",
  chapter: "chapter1", chapterLabel: "", chapterTitle: "", mission: "", dialogue: "", speaker: "", hint: "",
  health: 100, stamina: 100, waypoint: { x: 0, z: 5 }, interactionVisible: false, interactionKey: "E", toast: "",
  canChooseEnding: false, leaderboard: savedSessions(),
  customization: { character: "adam", carColor: "#333333", carModel: "porsche" },
  codex: [],
  minimapEntities: [],
  npcChat: { isOpen: false, messages: [], isTyping: false },
};

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const startedRef = useRef(false);
  const busRef = useRef(new GameEventBus());
  const [state, setState] = useState<GameUIState>(initialState);

  const send = useCallback((command: GameCommand) => busRef.current.emit("command", command), []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || startedRef.current) return;
    startedRef.current = true;
    let cancelled = false;
    let handle: GameHandle | null = null;
    let engine: Awaited<ReturnType<typeof createGameEngine>>["engine"] | null = null;
    const unlisten = busRef.current.on("ui", (patch) => {
      if (!cancelled) setState((previous) => ({ ...previous, ...patch }));
    });

    void (async () => {
      try {
        const created = await createGameEngine(canvas);
        engine = created.engine;
        if (cancelled) { engine.dispose(); return; }
        setState((previous) => ({ ...previous, engineKind: created.engineKind, loadingProgress: 4 }));
        handle = await createGameScene(created.engine, canvas, busRef.current, created.engineKind);
        if (cancelled) { handle.dispose(); created.engine.dispose(); return; }
        created.engine.runRenderLoop(() => handle?.scene.render());
      } catch {
        setState((previous) => ({ ...previous, loadingLabel: previous.locale === "ar" ? "تعذر بدء المشهد. أعد التحميل." : "The scene could not start. Reload to try again." }));
      }
    })();
    const onResize = () => engine?.resize();
    window.addEventListener("resize", onResize);
    return () => {
      cancelled = true;
      window.removeEventListener("resize", onResize);
      unlisten();
      handle?.dispose();
      engine?.dispose();
      busRef.current.clear();
      startedRef.current = false;
    };
  }, []);

  return <main className="game-shell"><canvas ref={canvasRef} className="game-canvas" style={{ touchAction: "none" }} /><GameHUD state={state} send={send} /></main>;
}
