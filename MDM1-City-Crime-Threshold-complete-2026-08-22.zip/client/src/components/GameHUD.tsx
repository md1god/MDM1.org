import { useEffect, useMemo, useRef, useState } from "react";
import { ChevronDown, CircleDotDashed, Crosshair, Gauge, Languages, Menu, MessageCircle, Palette, Settings2, X } from "lucide-react";
import { uiCopy } from "@/game/i18n";
import { chapterBackdrops } from "@/game/chapterVisuals";
import type { ChapterId, GameCommand, GameUIState, QualityLevel } from "@/game/types";
import { trpc } from "@/lib/trpc";

interface GameHUDProps {
  state: GameUIState;
  send: (command: GameCommand) => void;
}

const qualityLevels: Array<QualityLevel | "auto"> = ["auto", "Ultra", "High", "Medium", "Low"];
const carColors = ["#20242b", "#a93232", "#d0b35b", "#5c7892", "#f0f0ec"];
const chapterDeck: ChapterId[] = ["chapter1", "chapter2", "chapter3", "chapter4", "chapter5", "chapter6", "chapter7"];
const introSegments = [
  { ar: "قبل أن يبدأ التحقيق، كان هناك أثر لا ينام تحت الرمل.", en: "Before the case began, a trace slept beneath the sand." },
  { ar: "منزل قريب من الهرم. بئر ينفتح. وصوت روز يقطع الليل.", en: "A house near the pyramid. A well opens. Rose's voice cuts through the night." },
  { ar: "وراء الحجر، منشأة تحفظ سجلاً لم يكتبه عصر واحد.", en: "Beyond the stone, a facility keeps a record no single era wrote." },
  { ar: "كل بوابة تقود إلى زمن أقدم، وكل إجابة تترك سؤالاً أشد ظلمة.", en: "Every gate leads to an older time, and every answer leaves a darker question." },
  { ar: "حين يصل الأثر إلى المريخ، لن يكون آدم جونيور أقوى؛ سيكون مطالباً بالاختيار.", en: "When the trace reaches Mars, Adam Junior will not be stronger; he will have to choose." },
];

const codexLabel = (evidence: string, isArabic: boolean) => {
  const chapter = evidence.match(/chapter(\d)/)?.[1];
  return isArabic ? `دليل العتبة · الفصل ${chapter ?? "؟"}` : `THRESHOLD EVIDENCE · CHAPTER ${chapter ?? "?"}`;
};

export default function GameHUD({ state, send }: GameHUDProps) {
  const copy = uiCopy[state.locale];
  const [settingsOpen, setSettingsOpen] = useState(false);
  const customizing = state.mode === "intro";
  const [chatOpen, setChatOpen] = useState(false);
  const [mapExpanded, setMapExpanded] = useState(false);
  const [introBeat, setIntroBeat] = useState(0);
  const [soundOn, setSoundOn] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [chatDraft, setChatDraft] = useState("");
  const [chatMessages, setChatMessages] = useState<Array<{ role: "user" | "npc"; text: string }>>([]);
  const joystickRef = useRef<HTMLButtonElement>(null);
  const [joystick, setJoystick] = useState({ x: 0, y: 0 });
  const npcChat = trpc.game.chatWithNpc.useMutation();
  const minimapObjective = useMemo(() => ({
    left: `${Math.max(10, Math.min(90, 50 + state.waypoint.x * 1.45))}%`,
    top: `${Math.max(10, Math.min(90, 50 - state.waypoint.z * 1.45))}%`,
  }), [state.waypoint]);

  const handleJoystick = (event: React.PointerEvent<HTMLButtonElement>) => {
    const target = joystickRef.current;
    if (!target) return;
    const rect = target.getBoundingClientRect();
    const x = Math.max(-1, Math.min(1, (event.clientX - (rect.left + rect.width / 2)) / (rect.width / 2)));
    const y = Math.max(-1, Math.min(1, (event.clientY - (rect.top + rect.height / 2)) / (rect.height / 2)));
    setJoystick({ x: x * 22, y: y * 22 });
    send({ type: "touchMove", x, z: -y });
  };
  const resetJoystick = () => { setJoystick({ x: 0, y: 0 }); send({ type: "touchMove", x: 0, z: 0 }); };
  const isArabic = state.locale === "ar";
  useEffect(() => {
    if (!state.npcChat.isOpen && state.npcChat.messages.length === 0) return;
    setChatOpen(state.npcChat.isOpen);
    setChatMessages(state.npcChat.messages);
  }, [state.npcChat.isOpen, state.npcChat.messages]);
  useEffect(() => {
    if (state.mode !== "intro") return;
    const timer = window.setInterval(() => setIntroBeat((beat) => (beat + 1) % introSegments.length), 36000);
    return () => window.clearInterval(timer);
  }, [state.mode]);
  const toggleSound = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (soundOn) { audio.pause(); setSoundOn(false); return; }
    try { await audio.play(); setSoundOn(true); } catch { setSoundOn(false); }
  };

  const submitNpcChat = async () => {
    const text = chatDraft.trim();
    if (!text || npcChat.isPending) return;
    const next = [...chatMessages, { role: "user" as const, text }];
    setChatMessages(next);
    send({ type: "sendNpcMessage", text });
    setChatDraft("");
    try {
      const result = await npcChat.mutateAsync({ npcId: state.speaker || "threshold-narrator", messages: next, context: { chapter: state.chapter, mission: state.mission, location: `${state.waypoint.x},${state.waypoint.z}`, locale: state.locale } });
      const npcText = typeof result.text === "string" ? result.text : result.text.map((part) => "text" in part ? part.text : "").join(" ");
      setChatMessages((messages) => [...messages, { role: "npc", text: npcText }]);
    } catch {
      setChatMessages((messages) => [...messages, { role: "npc", text: isArabic ? "لا يصلني شيء عبر العتبة الآن." : "Nothing reaches me through the threshold yet." }]);
    }
  };

  return (
    <div className={`game-hud ${isArabic ? "is-ar" : "is-en"}`} dir={isArabic ? "rtl" : "ltr"}>
      <header className="hud-header">
        <div className="hud-brand"><img className="brand-symbol" src="/manus-storage/city-crime-threshold-logo-web_cd61aa6b.png" alt="" /><span>{copy.case}</span><i /><span className="brand-edition">WEB EDITION</span></div>
        <div className="hud-top-actions"><span className="engine-chip"><span className="signal-dot" />{state.engineKind}</span><button className="icon-button" onClick={() => setSettingsOpen((value) => !value)} aria-label={copy.settings}>{settingsOpen ? <X size={18} /> : <Settings2 size={18} />}</button></div>
      </header>

      {state.mode === "loading" && <section className="loading-screen"><div className="loading-mark"><CircleDotDashed size={48} strokeWidth={1.05} /></div><p className="eyebrow">{copy.case}</p><h1>{copy.load}</h1><div className="load-rule"><span style={{ width: `${state.loadingProgress}%` }} /></div><div className="load-info"><span>{state.loadingLabel}</span><strong>{state.loadingProgress}%</strong></div></section>}

      {state.mode === "intro" && <section className="intro-screen" aria-label="Game intro">
        <img className="intro-image" src={chapterBackdrops[state.chapter]} alt="" aria-label={isArabic ? "بيئة الفصل المختار" : "Selected chapter environment"} /><div className="intro-shade" /><div className="intro-grid" />
        <div className="intro-field-mark" aria-hidden="true"><img src="/manus-storage/city-crime-threshold-logo-web_cd61aa6b.png" alt="" /><span /><small>THRESHOLD / 01</small></div>
        <div className="intro-copy"><p className="eyebrow">{state.chapterLabel}</p><h1>{state.chapterTitle}</h1>            <p className="intro-narration">{state.dialogue}</p><p className="intro-timeline">{isArabic ? introSegments[introBeat].ar : introSegments[introBeat].en}</p><div className="intro-progress"><span style={{ width: `${((introBeat + 1) / introSegments.length) * 100}%` }} /></div>
          <div className="intro-actions"><button className="gold-button" onClick={() => { send({ type: "start" }); }}><span>{copy.start}</span><Crosshair size={17} /></button><button className="quiet-button" onClick={() => { send({ type: "skipIntro" }); }}>{copy.skip}</button><button className="quiet-button" onClick={() => void toggleSound()}>{soundOn ? (isArabic ? "كتم الموسيقى" : "MUTE THEME") : (isArabic ? "تشغيل الموسيقى" : "PLAY THEME")}</button></div><audio ref={audioRef} src="/manus-storage/city-crime-theme_8e41fffc.wav" loop preload="metadata" />
        </div>
        {customizing && <><section className="chapter-selector"><div className="drawer-heading"><span>{isArabic ? "اختيار الفصل" : "CHAPTER SELECT"}</span><span>{state.chapter.replace("chapter", "0")}</span></div><p className="quality-note">{isArabic ? "اختر أي فصل لتفحص بيئته وتبدأ مهمته مباشرة." : "Select any chapter to inspect its environment and start its mission directly."}</p><div className="chapter-grid">{chapterDeck.map((chapter) => <button key={chapter} className={state.chapter === chapter ? "active" : ""} onClick={() => send({ type: "selectChapter", chapter })} style={{ backgroundImage: `linear-gradient(0deg, rgba(3,8,12,.86), rgba(3,8,12,.08)), url(${chapterBackdrops[chapter]})` }}><span>{chapter.replace("chapter", "0")}</span><small>{isArabic ? "فصل" : "CH."}</small></button>)}</div></section><section className="customization-card"><div className="drawer-heading"><span>{isArabic ? "تجهيز المهمة" : "MISSION LOADOUT"}</span><Palette size={16} /></div><p className="quality-note">{isArabic ? "غيّر المظهر قبل دخول العتبة؛ هذه الاختيارات تجميلية ولا تمنح قوى خارقة." : "Choose a look before entering the threshold; these options are cosmetic and grant no superhuman abilities."}</p><div className="custom-row"><span>{isArabic ? "الشخصية" : "CHARACTER"}</span><button className={state.customization.character === "adam" ? "active" : ""} onClick={() => send({ type: "updateCustomization", patch: { character: "adam" } })}>ADAM JR.</button><button className={state.customization.character === "rose" ? "active" : ""} onClick={() => send({ type: "updateCustomization", patch: { character: "rose" } })}>ROSE</button></div><div className="custom-row"><span>{isArabic ? "السيارة" : "VEHICLE"}</span><button className={state.customization.carModel === "porsche" ? "active" : ""} onClick={() => send({ type: "updateCustomization", patch: { carModel: "porsche" } })}>PORSCHE 992</button><button className={state.customization.carModel === "sedan" ? "active" : ""} onClick={() => send({ type: "updateCustomization", patch: { carModel: "sedan" } })}>SEDAN</button></div><div className="color-swatches">{carColors.map((color) => <button key={color} aria-label={color} className={state.customization.carColor === color ? "selected" : ""} style={{ background: color }} onClick={() => send({ type: "updateCustomization", patch: { carColor: color } })} />)}</div></section></>}
        <div className="intro-meta"><span>COASTAL CITY</span><span>00:08 / INTRO</span></div>
      </section>}

      {state.mode !== "loading" && state.mode !== "intro" && <>
        <section className="mission-panel"><p className="eyebrow">{state.chapterLabel}</p><h2>{state.chapterTitle}</h2><div className="mission-rule" /><p className="mission-caption">{copy.mission}</p><p className="mission-text">{state.mission}</p></section>
        <section className={`minimap ${mapExpanded ? "expanded" : ""}`} aria-label="Mini map" onClick={() => setMapExpanded((open) => !open)}><span className="map-label">LOC / {state.chapter.replace("chapter", "0")} · {mapExpanded ? (isArabic ? "اضغط للتصغير" : "CLICK TO COLLAPSE") : (isArabic ? "اضغط للتكبير" : "CLICK TO EXPAND")}</span><div className="map-grid" /><span className="map-orbit orbit-a" /><span className="map-orbit orbit-b" />{state.minimapEntities.map((entity) => <button key={entity.id} className={`map-entity map-${entity.type}`} style={{ left: `${Math.max(8, Math.min(92, 50 + entity.x * 1.45))}%`, top: `${Math.max(8, Math.min(92, 50 - entity.z * 1.45))}%`, transform: `rotate(${entity.rotation ?? 0}rad)` }} title={entity.type} aria-label={entity.type} onClick={(event) => { event.stopPropagation(); if (entity.type === "npc") setChatOpen(true); }} />)}<span className="objective-dot" style={minimapObjective} /><span className="player-dot" /></section>
        <section className="vitals-panel"><div className="vital"><span>{copy.health}</span><div><i style={{ width: `${state.health}%` }} /></div><strong>{state.health}</strong></div><div className="vital"><span>{copy.stamina}</span><div><i className="stamina" style={{ width: `${state.stamina}%` }} /></div><strong>{state.stamina}</strong></div><div className="metrics"><span><Gauge size={13} /> {state.fps} {copy.fps}</span><span>{copy.quality}: {state.quality}{state.qualityAuto ? ` / ${copy.auto}` : ""}</span></div></section>
        <section className="dialogue-panel"><div className="narrator-presence"><img src="/manus-storage/narrator-hooded_a2af2223.png" alt="" /><span /></div><div><p className="speaker">{state.speaker}</p><p>{state.dialogue}</p></div></section><section className={`context-hint ${state.interactionVisible ? "is-active" : ""}`}><kbd>{state.interactionVisible ? state.interactionKey : "WASD"}</kbd><span>{state.hint}</span></section>{state.toast && <div className="toast-message">{state.toast}</div>}
        <button className="npc-chat-trigger" onClick={() => setChatOpen((open) => !open)}><MessageCircle size={16} /> {isArabic ? "تحدث مع العتبة" : "TALK TO THE THRESHOLD"}</button>
        {chatOpen && <section className="npc-chat-panel"><div className="drawer-heading"><span>{isArabic ? "محادثة طبيعية" : "NATURAL DIALOGUE"}</span><button className="icon-button" onClick={() => setChatOpen(false)}><X size={15} /></button></div><div className="npc-messages">{chatMessages.length === 0 && <p className="quality-note">{isArabic ? "اسأل روز أو الراوي عن المكان، لكن تذكّر أن الأثر لا يكشف كل شيء." : "Ask Rose or the narrator about the place, but remember: the trace does not reveal everything."}</p>}{chatMessages.map((message, index) => <p key={`${message.role}-${index}`} className={`npc-message ${message.role}`}>{message.text}</p>)}{npcChat.isPending && <p className="npc-message npc">…</p>}</div><div className="npc-input"><input value={chatDraft} onChange={(event) => setChatDraft(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") void submitNpcChat(); }} placeholder={isArabic ? "اكتب سؤالك..." : "Ask in natural language..."} /><button onClick={() => void submitNpcChat()}>{isArabic ? "إرسال" : "SEND"}</button></div></section>}
      </>}

      {settingsOpen && <aside className="settings-drawer"><div className="drawer-heading"><span>{copy.settings}</span><Settings2 size={16} /></div><div className="drawer-section"><span className="drawer-label">{copy.quality}</span><div className="quality-selector">{qualityLevels.map((quality) => { const active = quality === "auto" ? state.qualityAuto : state.quality === quality && !state.qualityAuto; return <button key={quality} className={active ? "active" : ""} onClick={() => send({ type: "setQuality", quality })}>{quality === "auto" ? copy.auto : quality}</button>; })}</div><p className="quality-note">{copy.qualityNote}</p></div><div className="drawer-section lang-row"><span className="drawer-label"><Languages size={14} /> لغة / Language</span><button onClick={() => send({ type: "setLocale", locale: isArabic ? "en" : "ar" })}>{isArabic ? "English" : "العربية"}</button></div><div className="drawer-section controls-list"><span className="drawer-label">{copy.controls}</span><p>{copy.tutorial}</p></div><div className="drawer-section session-log"><span className="drawer-label">{isArabic ? "Codex الأدلة" : "EVIDENCE CODEX"}</span>{state.codex.length === 0 ? <p>{isArabic ? "لم تكتشف دليلاً بعد." : "No evidence discovered yet."}</p> : state.codex.map((evidence) => <p key={evidence}>{codexLabel(evidence, isArabic)}</p>)}</div><div className="drawer-section session-log"><span className="drawer-label">{copy.leader}</span>{state.leaderboard.length === 0 ? <p>{copy.noScores}</p> : state.leaderboard.slice(0, 3).map((entry) => <p key={`${entry.completedAt}-${entry.decision}`}>{entry.durationSeconds}s · {entry.decision === "seal" ? copy.seal : copy.return}</p>)}</div></aside>}
      {state.mode === "ending" && <section className="ending-card"><p className="eyebrow">{state.speaker}</p><h2>{state.mission}</h2><p>{state.dialogue}</p><button className="quiet-button" onClick={() => window.location.reload()}>{isArabic ? "إعادة من البداية" : "RESTART FROM THE BEGINNING"}</button></section>}
      {state.canChooseEnding && <section className="choice-card"><p className="eyebrow">{copy.choose}</p><h2>{isArabic ? "لا توجد إجابة بلا ثمن." : "NO ANSWER COMES WITHOUT A COST."}</h2><div><button className="gold-button" onClick={() => send({ type: "chooseEnding", decision: "seal" })}>{copy.seal}</button><button className="quiet-button" onClick={() => send({ type: "chooseEnding", decision: "return" })}>{copy.return}</button></div></section>}
      <section className="touch-controls" aria-label="Touch controls"><button ref={joystickRef} className="joystick" onPointerDown={(event) => { event.currentTarget.setPointerCapture(event.pointerId); handleJoystick(event); }} onPointerMove={handleJoystick} onPointerUp={resetJoystick} onPointerCancel={resetJoystick}><span className="joystick-knob" style={{ transform: `translate(${joystick.x}px, ${joystick.y}px)` }} /><small>{copy.touchMove}</small></button><div className="touch-actions"><button onClick={() => send({ type: "interact" })}><span>E</span><small>{copy.touchInteract}</small></button><button onClick={() => send({ type: "action" })}><span>◌</span><small>{copy.touchAction}</small></button></div></section><button className="mobile-settings" onClick={() => setSettingsOpen((value) => !value)} aria-label={copy.settings}><Menu size={20} /><ChevronDown size={13} /></button>
    </div>
  );
}
