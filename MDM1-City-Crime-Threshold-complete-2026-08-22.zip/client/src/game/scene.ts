import { Engine } from "@babylonjs/core/Engines/engine";
import { WebGPUEngine } from "@babylonjs/core/Engines/webgpuEngine";
import type { AbstractEngine } from "@babylonjs/core/Engines/abstractEngine";
import type { Scene } from "@babylonjs/core/scene";
import { GameEventBus } from "./EventBus";
import { GameWorld } from "./GameWorld";
import type { EngineKind } from "./types";

export interface GameHandle {
  scene: Scene;
  dispose: () => void;
}

export interface GameEngine {
  engine: AbstractEngine;
  engineKind: EngineKind;
}

export async function createGameEngine(canvas: HTMLCanvasElement): Promise<GameEngine> {
  const supportsWebGPU = Boolean((navigator as Navigator & { gpu?: unknown }).gpu);
  if (supportsWebGPU) {
    try {
      const engine = new WebGPUEngine(canvas, { adaptToDeviceRatio: true, antialias: true });
      await engine.initAsync();
      return { engine, engineKind: "WebGPU" };
    } catch {
      // الرجوع إلى WebGL2 متعمد؛ اللعبة يجب أن تبدأ دائماً.
    }
  }
  return {
    engine: new Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true, adaptToDeviceRatio: true, disableWebGL2Support: false }),
    engineKind: "WebGL2",
  };
}

export async function createGameScene(engine: AbstractEngine, canvas: HTMLCanvasElement, bus: GameEventBus, engineKind: EngineKind): Promise<GameHandle> {
  const world = new GameWorld(engine, canvas, bus, engineKind);
  await world.initialize();
  return { scene: world.scene, dispose: () => world.dispose() };
}

