import { ArcRotateCamera } from "@babylonjs/core/Cameras/arcRotateCamera";
import { UniversalCamera } from "@babylonjs/core/Cameras/universalCamera";
import { Color3, Color4 } from "@babylonjs/core/Maths/math.color";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { DirectionalLight } from "@babylonjs/core/Lights/directionalLight";
import { HemisphericLight } from "@babylonjs/core/Lights/hemisphericLight";
import { PointLight } from "@babylonjs/core/Lights/pointLight";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
import { TransformNode } from "@babylonjs/core/Meshes/transformNode";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { PBRMaterial } from "@babylonjs/core/Materials/PBR/pbrMaterial";
import { Texture } from "@babylonjs/core/Materials/Textures/texture";
import { Layer } from "@babylonjs/core/Layers/layer";
import { DefaultRenderingPipeline } from "@babylonjs/core/PostProcesses/RenderPipeline/Pipelines/defaultRenderingPipeline";
import { SSAO2RenderingPipeline } from "@babylonjs/core/PostProcesses/RenderPipeline/Pipelines/ssao2RenderingPipeline";
import { Scene } from "@babylonjs/core/scene";
import { SceneLoader } from "@babylonjs/core/Loading/sceneLoader";
import "@babylonjs/loaders/glTF";
import type { AbstractEngine } from "@babylonjs/core/Engines/abstractEngine";
import "@babylonjs/core/Shaders/default.vertex";
import "@babylonjs/core/Shaders/default.fragment";
import "@babylonjs/core/Shaders/pbr.vertex";
import "@babylonjs/core/Shaders/pbr.fragment";
import "@babylonjs/core/Shaders/postprocess.vertex";
import "@babylonjs/core/Shaders/imageProcessing.fragment";
import "@babylonjs/core/Shaders/extractHighlights.fragment";
import "@babylonjs/core/Shaders/kernelBlur.vertex";
import "@babylonjs/core/Shaders/kernelBlur.fragment";
import "@babylonjs/core/Shaders/bloomMerge.fragment";
import "@babylonjs/core/Shaders/fxaa.vertex";
import "@babylonjs/core/Shaders/fxaa.fragment";
import "@babylonjs/core/Shaders/ssao2.fragment";
import "@babylonjs/core/Shaders/ssaoCombine.fragment";
import type { ChapterId, EngineKind, GameCommand, GameUIState, Locale, QualityLevel, CustomizationOptions, MinimapEntity } from "./types";
import { chapters, chapterOrder } from "./chapters";
import { chapterBackdrops } from "./chapterVisuals";
import { loadGameProgress, saveGameProgress } from "./progressStore";
import { GameEventBus } from "./EventBus";
import { text } from "./i18n";
import { InputManager } from "./InputManager";
import { PhysicsManager } from "./PhysicsManager";
import { QualityManager } from "./QualityManager";

const ASPHALT = {
  diffuse: "/manus-storage/asphalt_02_diff_1k_b1ae0786.jpg",
  normal: "/manus-storage/asphalt_02_nor_gl_1k_1d0b5f7b.jpg",
  roughness: "/manus-storage/asphalt_02_rough_1k_e9c017a1.jpg",
};

const GENERATED = {
  porsche: "/manus-storage/2024_porsche_992_gt3_r_texture_only_de531f2d.glb",
  rose: "/manus-storage/woman_standing_v8_97e56816.glb",
};

type ChapterRoot = TransformNode & { metadata?: { disposers?: Array<() => void> } };

export class GameWorld {
  readonly scene: Scene;
  private readonly camera: UniversalCamera;
  private readonly input = new InputManager();
  private readonly physics = new PhysicsManager();
  private readonly quality: QualityManager;
  private chapterRoot: ChapterRoot | null = null;
  private pipeline: DefaultRenderingPipeline | null = null;
  private ssao: SSAO2RenderingPipeline | null = null;
  private chapterId: ChapterId = "chapter1";
  private locale: Locale;
  private mode: GameUIState["mode"] = "loading";
  private customization: CustomizationOptions = { character: "adam", carColor: "#333333", carModel: "porsche" };
  private minimapEntities: MinimapEntity[] = [];
  private chapterStartedAt = performance.now();
  private interactionReady = false;
  private challengeArmed = false;
  private endingChoiceOpen = false;
  private startAt = performance.now();
  private demoTimer: number | null = null;
  private codex: string[] = [];
  private lastDecision: "seal" | "return" | undefined;
  private readonly unsubs: Array<() => void> = [];
  private readonly onPointerMove = (event: PointerEvent) => {
    if (document.pointerLockElement !== this.canvas || this.mode !== "playing") return;
    this.camera.rotation.y += event.movementX * 0.002;
    this.camera.rotation.x = Math.max(-1.25, Math.min(1.25, this.camera.rotation.x + event.movementY * 0.002));
  };
  private readonly onPointerDown = () => {
    if (this.mode === "playing" && document.pointerLockElement !== this.canvas) this.canvas.requestPointerLock?.();
  };

  constructor(
    private readonly engine: AbstractEngine,
    private readonly canvas: HTMLCanvasElement,
    private readonly bus: GameEventBus,
    private readonly engineKind: EngineKind,
  ) {
    this.scene = new Scene(engine);
    this.scene.clearColor = new Color4(0.021, 0.043, 0.06, 1);
    this.scene.fogMode = Scene.FOGMODE_EXP2;
    this.scene.fogDensity = 0.012;
    this.locale = navigator.language.toLowerCase().startsWith("ar") ? "ar" : "en";
    this.camera = new UniversalCamera("player_camera", new Vector3(0, 1.72, -18), this.scene);
    this.camera.minZ = 0.15;
    this.camera.fov = 0.92;
    this.camera.rotation = new Vector3(0.02, 0, 0);
    this.scene.activeCamera = this.camera;
    this.quality = new QualityManager(engine, {
      apply: (quality) => this.applyQuality(quality),
      report: (quality, auto, fps) => this.bus.emit("ui", { quality, qualityAuto: auto, fps }),
    });
  }

  async initialize() {
    this.bus.emit("ui", { loadingProgress: 8, loadingLabel: this.locale === "ar" ? "تهيئة المشهد" : "Initializing scene" });
    const savedProgress = await loadGameProgress();
    if (savedProgress) {
      this.chapterId = savedProgress.chapter;
      this.customization = savedProgress.customization;
      this.locale = savedProgress.locale;
      this.codex = savedProgress.codex;
      this.lastDecision = savedProgress.lastDecision;
    }
    this.emitCodex();
    this.createLighting();
    this.bus.emit("ui", { loadingProgress: 24, loadingLabel: this.locale === "ar" ? "تحميل خامات الأرض" : "Loading surface materials" });
    await this.loadFirstChapter();
    this.bus.emit("ui", { loadingProgress: 80, loadingLabel: this.locale === "ar" ? "إعداد نظام الأمان" : "Preparing safety systems" });
    void this.physics.initialize(this.scene).then((mode) => {
      this.bus.emit("ui", {
        toast: mode === "havok"
          ? this.locale === "ar" ? "Havok جاهز: التصادمات الفعلية مفعّلة." : "Havok ready: physics collisions enabled."
          : this.locale === "ar" ? "تم تفعيل حركة آمنة مبسطة." : "Safe fallback movement enabled.",
      });
    });
    this.input.attach();
    this.canvas.addEventListener("pointermove", this.onPointerMove);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.unsubs.push(this.bus.on("command", (command) => this.handleCommand(command)));
    this.scene.onBeforeRenderObservable.add(() => this.update());
    this.bus.emit("ui", { loadingProgress: 100, loadingLabel: this.locale === "ar" ? "جاهز" : "Ready", engineKind: this.engineKind });
    const params = new URLSearchParams(window.location.search);
    const requestedChapter = params.get("chapter") as ChapterId | null;
    const hasRequestedChapter = Boolean(requestedChapter && chapterOrder.includes(requestedChapter));
    if (hasRequestedChapter && requestedChapter) await this.setChapter(requestedChapter);
    if (params.has("demo")) this.startDemo(hasRequestedChapter);
    else this.showIntro();
    if (savedProgress) this.bus.emit("ui", { toast: this.locale === "ar" ? `استُعيد التقدم: الفصل ${this.chapterId.replace("chapter", "")}` : `Progress restored: Chapter ${this.chapterId.replace("chapter", "")}` });
  }

  private createLighting() {
    const hemi = new HemisphericLight("night_sky", new Vector3(0, 1, 0), this.scene);
    hemi.intensity = 0.38;
    hemi.diffuse = Color3.FromHexString("#9ab4ca");
    hemi.groundColor = Color3.FromHexString("#101517");
    const moon = new DirectionalLight("moon", new Vector3(-0.2, -1, 0.25), this.scene);
    moon.intensity = 0.72;
    moon.diffuse = Color3.FromHexString("#9ec8df");
    moon.position = new Vector3(18, 28, -20);
    const practical = new PointLight("door_lamp", new Vector3(-8, 5, 5), this.scene);
    practical.diffuse = Color3.FromHexString("#ffc86b");
    practical.intensity = 5.6;
    practical.range = 13;
  }

  private async loadFirstChapter() {
    await this.setChapter(this.chapterId, true);
  }

  private async loadTexture(url: string) {
    return new Promise<Texture>((resolve, reject) => {
      const texture = new Texture(url, this.scene, true, false, Texture.TRILINEAR_SAMPLINGMODE, () => resolve(texture), (_message, exception) => reject(exception));
    });
  }

  private async createGround(root: ChapterRoot, floorColor: string) {
    const ground = MeshBuilder.CreateGround("ground", { width: 96, height: 96, subdivisions: 2 }, this.scene);
    ground.parent = root;
    if (this.engineKind === "WebGL2") {
      const material = new StandardMaterial("asphalt_webgl_safe", this.scene);
      material.diffuseColor = Color3.FromHexString(floorColor).scale(0.72);
      material.specularColor = new Color3(0.015, 0.015, 0.015);
      try {
        const [albedo, normal] = await Promise.all([this.loadTexture(ASPHALT.diffuse), this.loadTexture(ASPHALT.normal)]);
        albedo.uScale = albedo.vScale = 14;
        normal.uScale = normal.vScale = 14;
        material.diffuseTexture = albedo;
        material.bumpTexture = normal;
      } catch {
        material.diffuseColor = Color3.FromHexString(floorColor).scale(0.45);
      }
      ground.material = material;
      return;
    }
    const material = new PBRMaterial("asphalt_pbr", this.scene);
    material.albedoColor = Color3.FromHexString(floorColor);
    material.metallic = 0;
    material.roughness = 0.93;
    try {
      const [albedo, normal, roughness] = await Promise.all([
        this.loadTexture(ASPHALT.diffuse),
        this.loadTexture(ASPHALT.normal),
        this.loadTexture(ASPHALT.roughness),
      ]);
      albedo.uScale = albedo.vScale = 14;
      normal.uScale = normal.vScale = 14;
      roughness.uScale = roughness.vScale = 14;
      material.albedoTexture = albedo;
      material.bumpTexture = normal;
      material.metallicTexture = roughness;
      material.useRoughnessFromMetallicTextureGreen = true;
      material.useMetallnessFromMetallicTextureBlue = false;
      material.useRoughnessFromMetallicTextureAlpha = false;
    } catch {
      material.albedoColor = Color3.FromHexString(floorColor).scale(0.55);
    }
    ground.material = material;
  }

  private material(name: string, color: string, metallic = 0, roughness = 0.7) {
    if (this.engineKind === "WebGL2") {
      const material = new StandardMaterial(name, this.scene);
      material.diffuseColor = Color3.FromHexString(color);
      material.specularColor = Color3.FromHexString("#0a0a0a").scale(Math.max(0.04, 1 - roughness));
      material.ambientColor = Color3.FromHexString(color).scale(0.08);
      material.emissiveColor = metallic > 0.8 ? Color3.FromHexString(color).scale(0.012) : Color3.Black();
      return material;
    }
    const material = new PBRMaterial(name, this.scene);
    material.albedoColor = Color3.FromHexString(color);
    material.metallic = metallic;
    material.roughness = roughness;
    return material;
  }

  private createBox(root: ChapterRoot, name: string, position: Vector3, scaling: Vector3, color: string, metallic = 0, roughness = 0.8) {
    const mesh = MeshBuilder.CreateBox(name, { size: 1 }, this.scene);
    mesh.parent = root;
    mesh.position = position;
    mesh.scaling = scaling;
    mesh.material = this.material(`${name}_material`, color, metallic, roughness);
    return mesh;
  }

  private createAccent(root: ChapterRoot, position: Vector3, color: string, scale = 1) {
    const ring = MeshBuilder.CreateTorus("threshold_marker", { diameter: 2.1 * scale, thickness: 0.08 * scale, tessellation: 32 }, this.scene);
    ring.parent = root;
    ring.position = position;
    ring.rotation.x = Math.PI / 2;
    const material = new StandardMaterial("marker_gold", this.scene);
    material.emissiveColor = Color3.FromHexString(color).scale(0.85);
    material.diffuseColor = Color3.FromHexString(color);
    ring.material = material;
    const core = MeshBuilder.CreateCylinder("marker_core", { height: 0.55 * scale, diameter: 0.38 * scale, tessellation: 20 }, this.scene);
    core.parent = root;
    core.position = position.add(new Vector3(0, 0.38 * scale, 0));
    core.material = material;
    return ring;
  }

  private async loadOptionalModel(root: ChapterRoot, url: string, position: Vector3, scale: number, rotationY = 0) {
    try {
      const response = await fetch(url, { cache: "force-cache" });
      if (!response.ok) throw new Error(`Asset request failed: ${response.status}`);
      const buffer = new Uint8Array(await response.arrayBuffer());
      const filename = url.slice(url.lastIndexOf("/") + 1) || "asset.glb";
      const result = await SceneLoader.ImportMeshAsync("", "", buffer, this.scene, null, ".glb", filename);
      if (this.chapterRoot !== root) { result.meshes.forEach((mesh) => mesh.dispose(false, true)); return; }
      const anchor = new TransformNode(`asset_anchor_${url.split("/").pop()}`, this.scene);
      anchor.parent = root;
      anchor.position = position;
      anchor.rotation.y = rotationY;
      anchor.scaling.setAll(scale);
      result.meshes.forEach((mesh) => { if (mesh !== result.meshes[0]) mesh.parent = anchor; });
      if (result.meshes[0]) result.meshes[0].parent = anchor;
      root.metadata?.disposers?.push(() => { result.meshes.forEach((mesh) => mesh.dispose(false, true)); anchor.dispose(); });
    } catch (error) {
      console.error("[GameWorld] Optional asset failed", { url, error });
      this.bus.emit("ui", { toast: this.locale === "ar" ? "تعذر تحميل أصل إضافي؛ استمر المسار الإجرائي." : "Optional asset unavailable; procedural fallback retained." });
    }
  }

  private createCinematicBackdrop(root: ChapterRoot, chapter: ChapterId) {
    const cinematicLayer = new Layer(`cinematic_layer_${chapter}`, chapterBackdrops[chapter], this.scene, true);
    cinematicLayer.isBackground = false;
    if (cinematicLayer.texture) cinematicLayer.texture.level = 0.78;
    root.metadata?.disposers?.push(() => cinematicLayer.dispose());
  }

  private buildCourtyard(root: ChapterRoot, color: string, accent: string) {
    this.createCinematicBackdrop(root, "chapter1");
    this.createBox(root, "villa_main", new Vector3(-7, 3.2, 8), new Vector3(13, 6.4, 5), "#b8ad9a", 0, 0.58);
    this.createBox(root, "villa_wing", new Vector3(-14, 2.4, 11), new Vector3(5.2, 4.8, 8), "#9f9585", 0, 0.64);
    this.createBox(root, "villa_roof", new Vector3(-7, 6.7, 8), new Vector3(14.2, 0.45, 6.1), "#273033", 0.25, 0.48);
    this.createBox(root, "villa_pergola", new Vector3(-2.1, 4.7, 5.3), new Vector3(4.8, 0.28, 3.5), "#7d6544", 0.1, 0.68);
    this.createBox(root, "villa_stair", new Vector3(-7, 0.42, 4.75), new Vector3(3.2, 0.75, 1.35), "#d0c2aa", 0, 0.78);
    this.createBox(root, "villa_door", new Vector3(-7, 1.7, 5.4), new Vector3(2.1, 3.4, 0.2), "#452e20", 0.15, 0.48);
    for (const x of [-11.2, -2.8]) {
      const windowFrame = this.createBox(root, "villa_window_frame", new Vector3(x, 3.8, 5.37), new Vector3(2.15, 2.15, 0.25), "#263033", 0.35, 0.32);
      const windowLight = this.createBox(root, "villa_window_light", new Vector3(x, 3.8, 5.18), new Vector3(1.66, 1.64, 0.08), "#d39f50", 0.16, 0.48);
      const glow = new PointLight(`window_glow_${x}`, new Vector3(x, 3.8, 4.8), this.scene);
      glow.diffuse = Color3.FromHexString("#eaa64c");
      glow.intensity = 2.2;
      glow.range = 5.6;
      root.metadata?.disposers?.push(() => { windowFrame.dispose(); windowLight.dispose(); glow.dispose(); });
    }
    this.createBox(root, "villa_wall_right", new Vector3(12, 2.5, 4), new Vector3(0.8, 5, 30), "#9b907f", 0, 0.82);
    this.createBox(root, "villa_wall_left", new Vector3(-22, 2.5, 4), new Vector3(0.8, 5, 30), "#9b907f", 0, 0.82);
    const well = MeshBuilder.CreateTorus("collapsed_well", { diameter: 5.3, thickness: 0.8, tessellation: 36 }, this.scene);
    well.parent = root;
    well.position = new Vector3(0, 0.5, 5);
    well.rotation.x = Math.PI / 2;
    well.material = this.material("well_stone", "#766d5b", 0, 0.94);
    this.createAccent(root, new Vector3(0, 1, 5), accent, 1.3);
    const carBody = this.createBox(root, "sedan_body", new Vector3(9, 1.1, -2), new Vector3(4.3, 1.3, 8), this.customization.carColor, 0.7, 0.3);
    carBody.rotation.y = -0.32;
    const carCabin = this.createBox(root, "sedan_cabin", new Vector3(9, 2.15, -2), new Vector3(3.45, 1.1, 4), "#263038", 0.55, 0.28);
    carCabin.rotation.y = -0.32;
    const carGlass = this.createBox(root, "sedan_glass", new Vector3(9, 2.21, -2), new Vector3(3.2, 0.88, 3.65), "#0a1822", 0.9, 0.08);
    carGlass.rotation.y = -0.32;
    for (const x of [7.4, 10.6]) for (const z of [-4.5, 0.5]) {
      const wheel = MeshBuilder.CreateCylinder("sedan_wheel", { height: 0.45, diameter: 1.35, tessellation: 20 }, this.scene);
      wheel.parent = root;
      wheel.position = new Vector3(x, 0.68, z);
      wheel.rotation.z = Math.PI / 2;
      wheel.rotation.y = -0.32;
      wheel.material = this.material("rubber", "#08090a", 0, 0.98);
    }
    this.minimapEntities = [
      { id: "player", type: "player", x: 0, z: 0 },
      { id: "objective", type: "objective", x: 0, z: 5 },
      { id: "car", type: "vehicle", x: 9, z: -2 },
      { id: "rose", type: "npc", x: -4, z: 4 },
    ];
    if (this.customization.carModel === "porsche") void this.loadOptionalModel(root, GENERATED.porsche, new Vector3(9, 0.2, -2), 1.65, -0.32);
    if (this.customization.character === "rose") void this.loadOptionalModel(root, GENERATED.rose, new Vector3(-4, 0, 4), 1.35, Math.PI);

  }

  private buildFacility(root: ChapterRoot, color: string, accent: string) {
    this.createCinematicBackdrop(root, "chapter2");
    for (const x of [-8, 8]) this.createBox(root, "facility_wall", new Vector3(x, 3, 8), new Vector3(1, 6, 36), color, 0.18, 0.5);
    this.createBox(root, "facility_ceiling", new Vector3(0, 6.2, 8), new Vector3(16, 0.6, 36), "#1c2a31", 0.45, 0.35);
    for (let z = -2; z <= 16; z += 6) this.createBox(root, "terminal", new Vector3(-6.7, 2.1, z), new Vector3(0.4, 2.8, 1.4), "#173740", 0.55, 0.35);
    this.createAccent(root, new Vector3(0, 1, 9), accent, 1.2);
    this.minimapEntities = [
      { id: "player", type: "player", x: 0, z: 0 },
      { id: "objective", type: "objective", x: 0, z: 9 },
    ];
  }

  private buildValley(root: ChapterRoot, color: string, accent: string) {
    this.createCinematicBackdrop(root, "chapter3");
    this.createAccent(root, new Vector3(0, 1, 24), accent, 1.4);
    this.minimapEntities = [
      { id: "player", type: "player", x: 0, z: 0 },
      { id: "objective", type: "objective", x: 0, z: 24 },
    ];
  }

  private buildSumer(root: ChapterRoot, color: string, accent: string) {
    this.createCinematicBackdrop(root, "chapter4");
    this.createBox(root, "ziggurat_base", new Vector3(0, 1.5, 12), new Vector3(18, 3, 18), color, 0, 0.98);
    this.createBox(root, "ziggurat_top", new Vector3(0, 4.5, 12), new Vector3(10, 3, 10), color, 0, 0.98);
    this.createAccent(root, new Vector3(0, 6.1, 12), accent, 1.1);
    this.minimapEntities = [
      { id: "player", type: "player", x: 0, z: 0 },
      { id: "objective", type: "objective", x: 0, z: 12 },
    ];
  }

  private buildTemple(root: ChapterRoot, color: string, accent: string) {
    this.createCinematicBackdrop(root, "chapter5");
    for (const x of [-6, 6]) for (let z = 0; z <= 24; z += 8) {
      const col = MeshBuilder.CreateCylinder("temple_col", { height: 8, diameter: 1.8, tessellation: 12 }, this.scene);
      col.parent = root;
      col.position = new Vector3(x, 4, z);
      col.material = this.material("temple_stone", color, 0, 0.92);
    }
    this.createAccent(root, new Vector3(0, 1, 28), accent, 1.5);
    this.minimapEntities = [
      { id: "player", type: "player", x: 0, z: 0 },
      { id: "objective", type: "objective", x: 0, z: 28 },
    ];
  }

  private buildTimeline(root: ChapterRoot, color: string, accent: string) {
    this.createCinematicBackdrop(root, "chapter6");
    const floor = MeshBuilder.CreateGround("timeline_floor", { width: 12, height: 120 }, this.scene);
    floor.parent = root;
    floor.position.z = 50;
    floor.material = this.material("timeline_mat", color, 0.8, 0.2);
    this.createAccent(root, new Vector3(0, 1, 90), accent, 1.2);
    this.minimapEntities = [
      { id: "player", type: "player", x: 0, z: 0 },
      { id: "objective", type: "objective", x: 0, z: 90 },
    ];
  }

  private buildMars(root: ChapterRoot, color: string, accent: string) {
    this.createCinematicBackdrop(root, "chapter7");
    const dome = MeshBuilder.CreateSphere("mars_dome", { diameter: 48, slice: 0.5 }, this.scene);
    dome.parent = root;
    dome.position = new Vector3(0, 0, 12);
    const material = this.material("dome_glass", "#9ec8df", 0.1, 0.1);
    if (material instanceof StandardMaterial) material.alpha = 0.24;
    else material.transparencyMode = 2;
    dome.material = material;
    this.createAccent(root, new Vector3(0, 1, 12), accent, 1.8);
    this.minimapEntities = [
      { id: "player", type: "player", x: 0, z: 0 },
      { id: "objective", type: "objective", x: 0, z: 12 },
    ];
  }

  private async setChapter(id: ChapterId, initial = false) {
    this.chapterId = id;
    const def = chapters[id];
    this.disposeChapter();
    this.chapterRoot = new TransformNode(`root_${id}`, this.scene) as ChapterRoot;
    this.chapterRoot.metadata = { disposers: [] };
    await this.createGround(this.chapterRoot, def.palette.floor);
    switch (def.architecture) {
      case "courtyard": this.buildCourtyard(this.chapterRoot, def.palette.primary, def.palette.accent); break;
      case "facility": this.buildFacility(this.chapterRoot, def.palette.primary, def.palette.accent); break;
      case "valley": this.buildValley(this.chapterRoot, def.palette.primary, def.palette.accent); break;
      case "sumer": this.buildSumer(this.chapterRoot, def.palette.primary, def.palette.accent); break;
      case "temple": this.buildTemple(this.chapterRoot, def.palette.primary, def.palette.accent); break;
      case "timeline": this.buildTimeline(this.chapterRoot, def.palette.primary, def.palette.accent); break;
      case "mars": this.buildMars(this.chapterRoot, def.palette.primary, def.palette.accent); break;
    }
    this.camera.position = new Vector3(0, 1.72, -18);
    this.camera.rotation = new Vector3(0.02, 0, 0);
    this.chapterStartedAt = performance.now();
    this.interactionReady = false;
    this.challengeArmed = false;
    if (!initial) this.emitChapterUI();
    if (!initial) this.persistProgress();
  }

  private emitChapterUI() {
    const def = chapters[this.chapterId];
    this.bus.emit("ui", {
      chapter: this.chapterId,
      chapterLabel: text(def.label, this.locale),
      chapterTitle: text(def.title, this.locale),
      mission: text(def.mission, this.locale),
      dialogue: text(def.dialogue, this.locale),
      speaker: text(def.speaker, this.locale),
      waypoint: def.objective,
      hint: text(def.hint, this.locale),
      interactionVisible: false,
      minimapEntities: this.minimapEntities,
    });
  }

  private showIntro() {
    this.mode = "intro";
    this.bus.emit("ui", { mode: "intro" });
    this.emitChapterUI();
  }

  private startPlay() {
    this.mode = "playing";
    this.bus.emit("ui", { mode: "playing" });
    if (!new URLSearchParams(window.location.search).has("demo")) this.canvas.requestPointerLock?.();
  }

  private handleCommand(command: GameCommand) {
    switch (command.type) {
      case "start": this.startPlay(); break;
      case "skipIntro": this.startPlay(); break;
      case "selectChapter": void this.setChapter(command.chapter).then(() => this.showIntro()); break;
      case "interact": if (this.interactionReady) this.onInteract(); break;
      case "action": if (this.challengeArmed) this.onChallengeComplete(); break;
      case "touchMove": this.input.setTouchMove(command.x, command.z); break;
      case "touchLook":
        this.camera.rotation.y += command.x * 0.015;
        this.camera.rotation.x = Math.max(-1.25, Math.min(1.25, this.camera.rotation.x + command.y * 0.015));
        break;
      case "setLocale": this.locale = command.locale; this.emitChapterUI(); this.persistProgress(); break;
      case "setQuality": this.quality.set(command.quality); break;
      case "chooseEnding": this.onEndingChosen(command.decision); break;
      case "updateCustomization":
        this.customization = { ...this.customization, ...command.patch };
        if (this.chapterId === "chapter1") void this.setChapter("chapter1");
        else this.persistProgress();
        break;
      case "toggleNpcChat":
        this.bus.emit("ui", { npcChat: { isOpen: command.open, messages: [], isTyping: false } });
        break;
    }
  }

  private update() {
    this.quality.update();
    if (this.mode !== "playing") return;
    const dt = this.engine.getDeltaTime() / 1000;
    const move = this.input.getMovement();
    const speed = this.input.isSprinting() ? 8.4 : 4.2;
    const forward = this.camera.getDirection(Vector3.Forward());
    forward.y = 0;
    forward.normalize();
    const right = this.camera.getDirection(Vector3.Right());
    right.y = 0;
    right.normalize();
    const velocity = forward.scale(move.z).add(right.scale(move.x)).scale(speed * dt);
    this.camera.position.addInPlace(velocity);
    this.camera.position.x = Math.max(-45, Math.min(45, this.camera.position.x));
    this.camera.position.z = Math.max(-45, Math.min(45, this.camera.position.z));
    const dist = Vector3.Distance(this.camera.position, new Vector3(chapters[this.chapterId].objective.x, 1, chapters[this.chapterId].objective.z));
    const npcDist = this.chapterId === "chapter1" ? Vector3.Distance(this.camera.position, new Vector3(-4, 1, 4)) : 99;
    const nearNpc = npcDist < 3.2;
    const ready = dist < 3.2 || nearNpc;
    if (ready !== this.interactionReady) {
      this.interactionReady = ready;
      this.bus.emit("ui", { interactionVisible: ready, hint: nearNpc ? (this.locale === "ar" ? "تحدث مع روز واضغط E" : "Talk to Rose with E") : undefined });
    }
    const playerEntity = this.minimapEntities.find(e => e.id === "player");
    if (playerEntity) {
      playerEntity.x = this.camera.position.x;
      playerEntity.z = this.camera.position.z;
      playerEntity.rotation = this.camera.rotation.y;
      this.bus.emit("ui", { minimapEntities: [...this.minimapEntities] });
    }
  }

  private onInteract() {
    const def = chapters[this.chapterId];
    if (this.chapterId === "chapter1" && Vector3.Distance(this.camera.position, new Vector3(-4, 1, 4)) < 3.2) {
      this.bus.emit("ui", { npcChat: { isOpen: true, messages: [], isTyping: false }, speaker: this.locale === "ar" ? "روز" : "ROSE", hint: this.locale === "ar" ? "اكتب سؤالك في نافذة الحوار" : "Type your question in the dialogue window", interactionVisible: false });
      return;
    }
    this.challengeArmed = true;
    this.bus.emit("ui", {
      dialogue: text(def.challenge, this.locale),
      hint: this.locale === "ar" ? "اضغط Space للتنفيذ" : "Press Space to execute",
      interactionVisible: false,
    });
  }

  private onChallengeComplete() {
    this.recordEvidence(this.chapterId);
    const index = chapterOrder.indexOf(this.chapterId);
    if (index < chapterOrder.length - 1) {
      void this.setChapter(chapterOrder[index + 1]);
      this.bus.emit("ui", { toast: this.locale === "ar" ? "تم فتح البوابة النجمية." : "Star gate opened." });
    } else {
      this.endingChoiceOpen = true;
      this.bus.emit("ui", { canChooseEnding: true });
    }
  }

  private onEndingChosen(decision: "seal" | "return") {
    this.lastDecision = decision;
    this.recordEvidence("chapter7");
    this.mode = "ending";
    const duration = Math.floor((performance.now() - this.startAt) / 1000);
    const entry = { completedAt: new Date().toISOString(), durationSeconds: duration, decision };
    const logs = JSON.parse(localStorage.getItem("mdm1-city-crime-sessions") ?? "[]");
    logs.unshift(entry);
    localStorage.setItem("mdm1-city-crime-sessions", JSON.stringify(logs.slice(0, 10)));
    this.bus.emit("ui", {
      mode: "ending",
      canChooseEnding: false,
      leaderboard: logs,
      speaker: this.locale === "ar" ? "الراوي" : "NARRATOR",
      mission: this.locale === "ar" ? "اكتمال الرحلة" : "JOURNEY COMPLETE",
      dialogue: decision === "seal"
        ? this.locale === "ar" ? "لقد اخترت إغلاق العتبة. العالم يعود لصمته، لكن الأسرار تظل تحت الرمال." : "You chose to seal the threshold. The world returns to silence, but the secrets remain beneath the sands."
        : this.locale === "ar" ? "لقد أبقيت البوابة مفتوحة. عصر جديد يبدأ، ولا أحد يعرف ما الذي سيخرج من العتبة." : "You kept the gate open. A new era begins, and no one knows what will emerge from the threshold.",
    });
    this.persistProgress();
  }

  private recordEvidence(chapter: ChapterId) {
    const entry = `threshold-evidence-${chapter}`;
    if (!this.codex.includes(entry)) this.codex.push(entry);
    this.emitCodex();
    this.persistProgress();
  }

  private emitCodex() {
    this.bus.emit("ui", { codex: [...this.codex] });
  }

  private persistProgress() {
    void saveGameProgress({
      version: 1,
      chapter: this.chapterId,
      customization: this.customization,
      locale: this.locale,
      codex: this.codex,
      lastDecision: this.lastDecision,
      updatedAt: Date.now(),
    });
  }

  private applyQuality(level: QualityLevel) {
    try {
      this.pipeline?.dispose();
      this.ssao?.dispose();
      this.scene.imageProcessingConfiguration.toneMappingEnabled = true;
      this.scene.imageProcessingConfiguration.toneMappingType = 1;
      this.scene.imageProcessingConfiguration.exposure = level === "Low" ? 0.88 : 1.02;
      this.scene.imageProcessingConfiguration.contrast = level === "Low" ? 1.04 : 1.15;
      if (level === "Low") {
        this.scene.fogDensity = 0.005;
        return;
      }
      this.scene.fogDensity = level === "Medium" ? 0.007 : 0.012;
      if (this.engineKind === "WebGL2") return;
      this.pipeline = new DefaultRenderingPipeline("rendering_pipeline", true, this.scene, [this.camera]);
      this.pipeline.imageProcessingEnabled = true;
      this.pipeline.bloomEnabled = level !== "Medium";
      this.pipeline.bloomThreshold = 0.82;
      this.pipeline.bloomWeight = level === "Ultra" ? 0.19 : 0.08;
      this.pipeline.bloomKernel = level === "Ultra" ? 56 : 34;
      this.pipeline.fxaaEnabled = level !== "Medium";
      this.pipeline.samples = level === "Ultra" ? 4 : 1;
      if (level === "High" || level === "Ultra") {
        this.ssao = new SSAO2RenderingPipeline("ssao", this.scene, { ssaoRatio: 0.5, blurRatio: 1 }, [this.camera]);
        this.ssao.radius = 2.4;
        this.ssao.totalStrength = level === "Ultra" ? 1.15 : 0.7;
        this.ssao.samples = level === "Ultra" ? 16 : 8;
      }
    } catch {
      this.pipeline?.dispose();
      this.pipeline = null;
      this.ssao?.dispose();
      this.ssao = null;
    }
  }

  private startDemo(holdRequestedChapter = false) {
    this.startPlay();
    if (holdRequestedChapter) return;
    let step = 0;
    this.demoTimer = window.setInterval(() => {
      step += 1;
      if (step < chapterOrder.length) void this.setChapter(chapterOrder[step]);
      else if (this.demoTimer) window.clearInterval(this.demoTimer);
    }, 2800);
  }

  private disposeChapter() {
    if (!this.chapterRoot) return;
    this.chapterRoot.metadata?.disposers?.forEach((dispose: () => void) => dispose());
    this.chapterRoot.getChildMeshes(false).forEach((mesh) => mesh.dispose(false, true));
    this.chapterRoot.dispose(false, true);
    this.chapterRoot = null;
  }

  dispose() {
    this.input.dispose();
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    if (this.demoTimer) window.clearInterval(this.demoTimer);
    this.unsubs.forEach((unsubscribe) => unsubscribe());
    this.disposeChapter();
    this.physics.dispose();
    this.pipeline?.dispose();
    this.ssao?.dispose();
    this.scene.dispose();
  }
}

void ArcRotateCamera;
