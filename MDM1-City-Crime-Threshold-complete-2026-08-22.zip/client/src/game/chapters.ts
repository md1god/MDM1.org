import type { ChapterId, LocalizedText } from "./types";

export interface ChapterDefinition {
  id: ChapterId;
  label: LocalizedText;
  title: LocalizedText;
  mission: LocalizedText;
  dialogue: LocalizedText;
  speaker: LocalizedText;
  hint: LocalizedText;
  challenge: LocalizedText;
  palette: { sky: string; floor: string; primary: string; accent: string };
  objective: { x: number; y: number; z: number };
  architecture: "courtyard" | "facility" | "valley" | "sumer" | "temple" | "timeline" | "mars";
}

const ar = (arText: string, en: string): LocalizedText => ({ ar: arText, en });

export const chapters: Record<ChapterId, ChapterDefinition> = {
  chapter1: {
    id: "chapter1",
    label: ar("الفصل 01", "CHAPTER 01"),
    title: ar("البئر والهرم", "THE WELL & THE PYRAMID"),
    mission: ar("اتبع صرخة روز إلى البئر المنهار.", "Follow Rose's cry to the collapsed well."),
    dialogue: ar("روز: Adam! The floor gave way—there is something under the house.", "Rose: Adam! The floor gave way—there is something under the house."),
    speaker: ar("روز · English / ترجمة", "ROSE · ENGLISH / SUBTITLED"),
    hint: ar("اقترب من العلامة واضغط E", "Move to the marker and press E"),
    challenge: ar("شغّل آلية العتبة بالضغط على Space", "Power the threshold mechanism with Space"),
    palette: { sky: "#07121d", floor: "#24282a", primary: "#84745e", accent: "#d6a33e" },
    objective: { x: 0, y: 0, z: 5 },
    architecture: "courtyard",
  },
  chapter2: {
    id: "chapter2",
    label: ar("الفصل 02", "CHAPTER 02"),
    title: ar("المنشأة السرية", "THE HIDDEN FACILITY"),
    mission: ar("اعثر على ملف مشروع صفر داخل غرفة السجلات.", "Locate the Project Zero file in the records chamber."),
    dialogue: ar("آدم: لا أحد بنى هذا المكان ليبقى سراً إلى الأبد.", "Adam: No one built this place to stay hidden forever."),
    speaker: ar("آدم", "ADAM"),
    hint: ar("افحص الطرف المضيء واضغط E", "Inspect the lit terminal with E"),
    challenge: ar("أرسل أمر التخفي بالضغط على Space", "Send the stealth bypass with Space"),
    palette: { sky: "#081019", floor: "#1b2429", primary: "#60727a", accent: "#70c4be" },
    objective: { x: 0, y: 0, z: 9 },
    architecture: "facility",
  },
  chapter3: {
    id: "chapter3",
    label: ar("الفصل 03", "CHAPTER 03"),
    title: ar("وادي أقدم من الأثر", "A VALLEY BEFORE THE TRACE"),
    mission: ar("التقط قطعة الطاقة من الحافة الصخرية دون البقاء مكشوفاً.", "Recover the energy fragment from the rock shelf without lingering exposed."),
    dialogue: ar("روز: لا أعرف أسماء هذه المخلوقات، لكنني أعرف أن علينا الهدوء.", "Rose: I don't know what to call those creatures, but I know we must stay quiet."),
    speaker: ar("روز · English / ترجمة", "ROSE · ENGLISH / SUBTITLED"),
    hint: ar("التقط القطعة عند العمود الذهبي", "Reach the gold shard and press E"),
    challenge: ar("ثبّت قطعة الطاقة بالضغط على Space", "Stabilize the energy fragment with Space"),
    palette: { sky: "#546656", floor: "#504534", primary: "#897b57", accent: "#e4bf65" },
    objective: { x: 0, y: 0, z: 11 },
    architecture: "valley",
  },
  chapter4: {
    id: "chapter4",
    label: ar("الفصل 04", "CHAPTER 04"),
    title: ar("أول المدن", "THE FIRST CITIES"),
    mission: ar("أعد توجيه رمز السماء عند الزقورة.", "Realign the sky symbol at the ziggurat."),
    dialogue: ar("آدم: المدن تتغير، لكن الذين تركوا العلامات يعرفون طريق العودة.", "Adam: Cities change, but those who left markers knew a way back."),
    speaker: ar("آدم", "ADAM"),
    hint: ar("فعّل القرص الحجري بـE", "Activate the stone disc with E"),
    challenge: ar("أعد توجيه رمز السماء بالضغط على Space", "Reorient the sky symbol with Space"),
    palette: { sky: "#3b3450", floor: "#554433", primary: "#a87844", accent: "#d9c275" },
    objective: { x: 0, y: 0, z: 10 },
    architecture: "sumer",
  },
  chapter5: {
    id: "chapter5",
    label: ar("الفصل 05", "CHAPTER 05"),
    title: ar("عين العبور", "THE PASSAGE EYE"),
    mission: ar("عاير حلقة العبور داخل المعبد القديم.", "Calibrate the passage ring inside the old temple."),
    dialogue: ar("روز: هذه ليست خريطة. إنها طريقة لقياس ما فقدناه.", "Rose: This isn't a map. It is a way to measure what we lost."),
    speaker: ar("روز · English / ترجمة", "ROSE · ENGLISH / SUBTITLED"),
    hint: ar("اقترب من الحلقة واضغط E", "Approach the ring and press E"),
    challenge: ar("عاير العين الذهبية بالضغط على Space", "Calibrate the golden eye with Space"),
    palette: { sky: "#172536", floor: "#665442", primary: "#b39161", accent: "#d6a33e" },
    objective: { x: 0, y: 0, z: 10 },
    architecture: "temple",
  },
  chapter6: {
    id: "chapter6",
    label: ar("الفصل 06", "CHAPTER 06"),
    title: ar("خط التاريخ", "THE TIMELINE"),
    mission: ar("اعبر ممر الزمان وشاهد تعاقب الأمم.", "Cross the passage of time and witness the succession of nations."),
    dialogue: ar("آدم: كل زمن يترك تحذيراً لمن يأتي بعده.", "Adam: Every era leaves a warning for the people who follow."),
    speaker: ar("آدم", "ADAM"),
    hint: ar("سر نحو النهاية واضغط E", "Walk to the end and press E"),
    challenge: ar("ثبّت الرؤية بالضغط على Space", "Commit the vision with Space"),
    palette: { sky: "#20222c", floor: "#373745", primary: "#796d5a", accent: "#b2d5c5" },
    objective: { x: 0, y: 0, z: 90 },
    architecture: "timeline",
  },
  chapter7: {
    id: "chapter7",
    label: ar("الفصل 07", "CHAPTER 07"),
    title: ar("قرار المريخ", "THE MARS DECISION"),
    mission: ar("واجه حارس العتبة وحدد مصير قلب البوابة.", "Face the threshold keeper and decide the gate core's fate."),
    dialogue: ar("روز: هذه المرة لا يكفي أن نعرف الطريق. يجب أن نختار ماذا نترك خلفنا.", "Rose: This time, knowing the route is not enough. We must choose what to leave behind."),
    speaker: ar("روز · English / ترجمة", "ROSE · ENGLISH / SUBTITLED"),
    hint: ar("ادخل منصة القرار واضغط E", "Enter the decision platform and press E"),
    challenge: ar("اختر مصير القلب عند منصة القرار", "Choose the core's fate at the decision platform"),
    palette: { sky: "#251b24", floor: "#713b34", primary: "#c9b19b", accent: "#f0c169" },
    objective: { x: 0, y: 0, z: 12 },
    architecture: "mars",
  },
};

export const chapterOrder: ChapterId[] = ["chapter1", "chapter2", "chapter3", "chapter4", "chapter5", "chapter6", "chapter7"];
