import HavokPhysics from "@babylonjs/havok";
import havokWasmUrl from "@babylonjs/havok/lib/esm/HavokPhysics.wasm?url";
import { HavokPlugin } from "@babylonjs/core/Physics/v2/Plugins/havokPlugin";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import type { Scene } from "@babylonjs/core/scene";

type HavokFactoryOptions = { locateFile?: (path: string) => string };

export class PhysicsManager {
  mode: "havok" | "fallback" = "fallback";
  private plugin: HavokPlugin | null = null;

  async initialize(scene: Scene) {
    try {
      const havok = await HavokPhysics({ locateFile: (_path: string) => havokWasmUrl } as HavokFactoryOptions);
      this.plugin = new HavokPlugin(true, havok);
      scene.enablePhysics(new Vector3(0, -9.81, 0), this.plugin);
      this.mode = "havok";
    } catch {
      this.mode = "fallback";
    }
    return this.mode;
  }

  clampToPlayableBounds(position: Vector3) {
    position.x = Math.max(-48, Math.min(48, position.x));
    position.z = Math.max(-48, Math.min(48, position.z));
    position.y = Math.max(1.65, position.y);
  }

  dispose() {
    this.plugin?.dispose();
    this.plugin = null;
  }
}
