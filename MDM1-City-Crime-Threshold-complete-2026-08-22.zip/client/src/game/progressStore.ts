import type { ChapterId, CustomizationOptions, Locale } from "./types";

export interface GameProgress {
  version: 1;
  chapter: ChapterId;
  customization: CustomizationOptions;
  locale: Locale;
  codex: string[];
  lastDecision?: "seal" | "return";
  updatedAt: number;
}

const DB_NAME = "mdm1-city-crime";
const STORE_NAME = "progress";
const SAVE_KEY = "primary";
const FALLBACK_KEY = "mdm1-city-crime-progress";

export const normalizeGameProgress = (input: GameProgress): GameProgress => ({
  ...input,
  version: 1,
  codex: Array.from(new Set(input.codex)).slice(-64),
  updatedAt: Number.isFinite(input.updatedAt) ? input.updatedAt : Date.now(),
});

const openProgressDb = () => new Promise<IDBDatabase>((resolve, reject) => {
  const request = indexedDB.open(DB_NAME, 1);
  request.onupgradeneeded = () => {
    if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME);
  };
  request.onsuccess = () => resolve(request.result);
  request.onerror = () => reject(request.error);
});

const fallbackLoad = (): GameProgress | null => {
  try {
    const raw = window.localStorage.getItem(FALLBACK_KEY);
    return raw ? normalizeGameProgress(JSON.parse(raw) as GameProgress) : null;
  } catch { return null; }
};

const fallbackSave = (progress: GameProgress) => {
  try { window.localStorage.setItem(FALLBACK_KEY, JSON.stringify(progress)); } catch { /* non-persistent private mode */ }
};

export async function loadGameProgress(): Promise<GameProgress | null> {
  if (typeof window === "undefined") return null;
  if (!("indexedDB" in window)) return fallbackLoad();
  try {
    const db = await openProgressDb();
    const result = await new Promise<GameProgress | undefined>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, "readonly");
      const request = transaction.objectStore(STORE_NAME).get(SAVE_KEY);
      request.onsuccess = () => resolve(request.result as GameProgress | undefined);
      request.onerror = () => reject(request.error);
    });
    db.close();
    return result ? normalizeGameProgress(result) : fallbackLoad();
  } catch { return fallbackLoad(); }
}

export async function saveGameProgress(progress: GameProgress): Promise<void> {
  if (typeof window === "undefined") return;
  const normalized = normalizeGameProgress(progress);
  fallbackSave(normalized);
  if (!("indexedDB" in window)) return;
  try {
    const db = await openProgressDb();
    await new Promise<void>((resolve, reject) => {
      const transaction = db.transaction(STORE_NAME, "readwrite");
      transaction.objectStore(STORE_NAME).put(normalized, SAVE_KEY);
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error);
    });
    db.close();
  } catch { /* LocalStorage fallback was written first. */ }
}
