import type { GameCommand } from "./types";

export class InputManager {
  private pressed = new Set<string>();
  private touchMove = { x: 0, z: 0 };
  private touchLook = { x: 0, y: 0 };
  private wantsInteract = false;
  private wantsAction = false;
  private readonly onKeyDown = (event: KeyboardEvent) => {
    const key = event.key.toLowerCase();
    if (["w", "a", "s", "d", "e", " ", "shift"].includes(key)) event.preventDefault();
    this.pressed.add(key);
    if (key === "e") this.wantsInteract = true;
    if (key === " ") this.wantsAction = true;
  };
  private readonly onKeyUp = (event: KeyboardEvent) => this.pressed.delete(event.key.toLowerCase());

  attach() {
    window.addEventListener("keydown", this.onKeyDown, { passive: false });
    window.addEventListener("keyup", this.onKeyUp);
  }

  dispose() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
  }

  setTouchMove(x: number, z: number) {
    this.touchMove = { x, z };
  }

  setTouchLook(x: number, y: number) {
    this.touchLook = { x, y };
  }

  getMovement() {
    const x = (this.pressed.has("d") ? 1 : 0) - (this.pressed.has("a") ? 1 : 0) + this.touchMove.x;
    const z = (this.pressed.has("w") ? 1 : 0) - (this.pressed.has("s") ? 1 : 0) + this.touchMove.z;
    const length = Math.hypot(x, z) || 1;
    return { x: x / length, z: z / length };
  }

  isSprinting() {
    return this.pressed.has("shift");
  }

  consumeLook() {
    const result = { ...this.touchLook };
    this.touchLook = { x: 0, y: 0 };
    return result;
  }

  consumeInteract() {
    const value = this.wantsInteract;
    this.wantsInteract = false;
    return value;
  }

  consumeAction() {
    const value = this.wantsAction;
    this.wantsAction = false;
    return value;
  }
}
