import type { AbstractEngine } from "@babylonjs/core/Engines/abstractEngine";
import type { QualityLevel } from "./types";

export interface QualityTarget {
  apply: (quality: QualityLevel) => void;
  report: (quality: QualityLevel, auto: boolean, fps: number) => void;
}

const ranks: QualityLevel[] = ["Low", "Medium", "High", "Ultra"];

export class QualityManager {
  quality: QualityLevel;
  auto = true;
  private samples: number[] = [];
  private lastDecision = performance.now();

  constructor(private engine: AbstractEngine, private target: QualityTarget) {
    const cores = navigator.hardwareConcurrency ?? 4;
    const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory ?? 4;
    const mobile = matchMedia("(pointer: coarse)").matches;
    this.quality = mobile || cores <= 4 || memory <= 4 ? "Medium" : cores >= 12 && memory >= 8 ? "Ultra" : "High";
    this.apply();
  }

  set(value: QualityLevel | "auto") {
    this.auto = value === "auto";
    if (value !== "auto") this.quality = value;
    this.apply();
  }

  update() {
    const fps = Math.max(0, Math.round(this.engine.getFps()));
    this.samples.push(fps);
    if (this.samples.length > 90) this.samples.shift();
    const now = performance.now();
    if (this.auto && this.samples.length >= 45 && now - this.lastDecision > 4500) {
      const average = this.samples.reduce((sum, value) => sum + value, 0) / this.samples.length;
      const index = ranks.indexOf(this.quality);
      if (average < 43 && index > 0) this.quality = ranks[index - 1];
      if (average > 58 && index < ranks.length - 1) this.quality = ranks[index + 1];
      this.lastDecision = now;
      this.apply();
    }
    this.target.report(this.quality, this.auto, fps);
  }

  private apply() {
    const scale: Record<QualityLevel, number> = { Ultra: 1, High: 1.12, Medium: 1.35, Low: 1.65 };
    this.engine.setHardwareScalingLevel(scale[this.quality]);
    this.target.apply(this.quality);
  }
}
