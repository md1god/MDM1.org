import { describe, expect, it } from "vitest";
import { chapters, chapterOrder } from "./chapters";

describe("City Crime chapter data", () => {
  it("contains seven playable chapters in a deterministic order", () => {
    expect(chapterOrder).toHaveLength(7);
    for (const id of chapterOrder) {
      expect(chapters[id].mission.ar.length).toBeGreaterThan(0);
      expect(chapters[id].mission.en.length).toBeGreaterThan(0);
      expect(chapters[id].challenge.ar.length).toBeGreaterThan(0);
      expect(chapters[id].challenge.en.length).toBeGreaterThan(0);
      expect(Number.isFinite(chapters[id].objective.x)).toBe(true);
      expect(Number.isFinite(chapters[id].objective.z)).toBe(true);
    }
  });

  it("ends on the Mars chapter and keeps the narrative progression explicit", () => {
    expect(chapterOrder.at(-1)).toBe("chapter7");
    expect(chapters.chapter7.architecture).toBe("mars");
    expect(chapters.chapter7.title.en).toContain("MARS");
  });
});
