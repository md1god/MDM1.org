import type { GameEventMap } from "./types";

/** إطار أحداث صغير يفصل حالة React عن قواعد Babylon. */
export class GameEventBus {
  private listeners = new Map<keyof GameEventMap, Set<(payload: never) => void>>();

  on<K extends keyof GameEventMap>(event: K, listener: (payload: GameEventMap[K]) => void) {
    const bucket = this.listeners.get(event) ?? new Set();
    bucket.add(listener as (payload: never) => void);
    this.listeners.set(event, bucket);
    return () => bucket.delete(listener as (payload: never) => void);
  }

  emit<K extends keyof GameEventMap>(event: K, payload: GameEventMap[K]) {
    this.listeners.get(event)?.forEach((listener) => listener(payload as never));
  }

  clear() {
    this.listeners.clear();
  }
}
