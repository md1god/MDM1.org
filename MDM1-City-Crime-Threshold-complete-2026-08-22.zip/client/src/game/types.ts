export type EngineKind = "WebGPU" | "WebGL2";
export type QualityLevel = "Ultra" | "High" | "Medium" | "Low";
export type Locale = "ar" | "en";
export type GameMode = "loading" | "intro" | "playing" | "ending";

export type ChapterId =
  | "chapter1"
  | "chapter2"
  | "chapter3"
  | "chapter4"
  | "chapter5"
  | "chapter6"
  | "chapter7";

export interface LocalizedText {
  ar: string;
  en: string;
}

export interface LeaderboardEntry {
  completedAt: string;
  durationSeconds: number;
  decision: "seal" | "return";
}

export interface CustomizationOptions {
  character: "adam" | "rose";
  carColor: string;
  carModel: "porsche" | "sedan";
}

export interface MinimapEntity {
  id: string;
  type: "player" | "objective" | "vehicle" | "npc";
  x: number;
  z: number;
  rotation?: number;
}

export interface GameUIState {
  mode: GameMode;
  engineKind: EngineKind;
  quality: QualityLevel;
  qualityAuto: boolean;
  fps: number;
  loadingProgress: number;
  loadingLabel: string;
  locale: Locale;
  chapter: ChapterId;
  chapterLabel: string;
  chapterTitle: string;
  mission: string;
  dialogue: string;
  speaker: string;
  hint: string;
  health: number;
  stamina: number;
  waypoint: { x: number; z: number };
  interactionVisible: boolean;
  interactionKey: string;
  toast: string;
  canChooseEnding: boolean;
  leaderboard: LeaderboardEntry[];
  customization: CustomizationOptions;
  codex: string[];
  minimapEntities: MinimapEntity[];
  npcChat: {
    isOpen: boolean;
    messages: { role: "user" | "npc"; text: string }[];
    isTyping: boolean;
  };
}

export type GameCommand =
  | { type: "start" }
  | { type: "skipIntro" }
  | { type: "selectChapter"; chapter: ChapterId }
  | { type: "interact" }
  | { type: "action" }
  | { type: "chooseEnding"; decision: "seal" | "return" }
  | { type: "setQuality"; quality: QualityLevel | "auto" }
  | { type: "setLocale"; locale: Locale }
  | { type: "touchMove"; x: number; z: number }
  | { type: "touchLook"; x: number; y: number }
  | { type: "updateCustomization"; patch: Partial<CustomizationOptions> }
  | { type: "sendNpcMessage"; text: string }
  | { type: "toggleNpcChat"; open: boolean };

export interface GameEventMap {
  ui: Partial<GameUIState>;
  command: GameCommand;
}
