import type { ChapterId } from "./types";

export const chapterBackdrops: Record<ChapterId, string> = {
  chapter1: "/manus-storage/mdm1-chapter-01-luxury-giza-villa_59e37171.jpg",
  chapter2: "/manus-storage/mdm1-chapter-02-facility_e053baed.jpg",
  chapter3: "/manus-storage/mdm1-chapter-03-valley_251e7c82.jpg",
  chapter4: "/manus-storage/mdm1-chapter-04-sumer_f17bd541.jpg",
  chapter5: "/manus-storage/mdm1-chapter-05-temple_0c17c5cc.jpg",
  chapter6: "/manus-storage/mdm1-chapter-06-timeline_c0b92128.jpg",
  chapter7: "/manus-storage/mdm1-chapter-07-mars_7f1d1edb.jpg",
};
