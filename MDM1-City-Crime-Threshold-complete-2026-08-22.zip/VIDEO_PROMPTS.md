# برومبتات الفيديو الأصلية — MDM1 City Crime — The Threshold

هذا الملف مكتوب للتوليد لاحقاً عندما تتاح حصة الفيديو. المقاطع **أصلية بالكامل**، ولا تستخدم صور المستخدم أو فيديوهاته أو صفحة CC Game كأصول إدخال. تدعم المشاهد قصة غامضة، مع احترام الحساسية الدينية: لا تمثيل لأي نبي أو مَلَك أو شخصية دينية، ولا آيات أو رموز دينية مقروءة.

## إعداد موحد لكل المقاطع

استخدم المقاس **16:9 landscape** ومدة **8 ثوانٍ** لكل لقطة، ودقة 720p على الأقل. اعتمد حركة كاميرا متصلة وطبيعية، ودرجات فحمية، أزرق بارد، ذهب معتّق محدود، وواقعية مواد PBR. يجب أن تكون جميع اللقطات **بلا نص، بلا شعار، بلا واجهة، بلا وجوه مشاهير، بلا رسوم كرتونية، وبلا مؤثرات نيون مفرطة**. عند توفر دعم صورة مرجعية، استخدم لوحة الأسلوب الأصلية للمشروع فقط: `/manus-storage/mdm1-threshold-cinematic-style-reference_9856eead.jpg`.

## الإنترو الكامل — 180 ثانية تقريباً

يشغل التسلسل التالي 23 لقطة قصيرة متتابعة. تُوصل اللقطات بمزج صوتي قصير وقطع على الحركة، ثم يُعرض زر البدء فوق المشهد الأخير. الصوت منفصل عن الفيديو حتى تبقى خاصية الكتم في الواجهة فعالة.

| الترتيب | المدة | البرومبت الجاهز |
| --- | ---: | --- |
| 01 | 8 ث | `Cinematic macro shot of dark wet clay slowly forming abstract ripples under a distant dawn glow; no human shape, only earth, water and dust. Slow forward dolly, photorealistic PBR mud, charcoal and warm amber palette, solemn and grounded, no text, no people, no religious imagery.` |
| 02 | 8 ث | `A low aerial pass over an empty primordial desert before sunrise. Wind creates delicate lines in untouched sand; a single circle of water glimmers and fades. Realistic natural light, slow camera drift, no figures, no architecture, no text.` |
| 03 | 8 ث | `Anonymous human footprints appear one by one in damp sand as wind erases older tracks. The camera follows the marks at ground level; no body is visible. Filmic realism, restrained blue dawn and muted gold, no religious symbols.` |
| 04 | 8 ث | `A towering ancient tree seen only as a silhouette through soft mist; dew falls from leaves and the camera slowly turns away toward an empty horizon. Natural wonder, not paradise depiction, no people, no fruit closeup, no text.` |
| 05 | 8 ث | `A violent but natural weather transition: dark clouds roll over an empty desert and rain begins on stone. The camera is sheltered beneath a rock overhang; realistic rain, lightning far away, no characters.` |
| 06 | 8 ث | `Time passes across an abandoned stone settlement through shadows sliding over walls, clay jars and an unlit firepit. No people appear; the camera moves through a quiet doorway. Photorealistic archaeology, no readable text.` |
| 07 | 8 ث | `A cinematic overhead glide across anonymous ruins becoming layered foundations from different eras; wind carries dust between stones. Smooth morph-free match cut feeling, no figures, no iconography, no text.` |
| 08 | 8 ث | `A forgotten brass survey instrument turns slowly on a stone table under moonlight. Its needle settles toward a buried underground direction; dust motes move naturally. Grounded techno-archaeological realism, no labels.` |
| 09 | 8 ث | `Night aerial of modern Cairo outskirts at a respectful distance, ordinary rooftop lights and distant traffic, the Giza plateau barely visible through atmospheric haze. No people, no recognisable brands, no text.` |
| 10 | 8 ث | `Street-level cinematic glide through a quiet realistic courtyard near Giza after midnight. Weathered limestone walls, a modest lamp, damp dust and distant pyramid silhouette. Empty scene, no characters, no title card.` |
| 11 | 8 ث | `The camera approaches an old circular stone well in the courtyard. Warm lamp light flickers while a subtle cyan reflection appears from below. Realistic stone, slow descent, no portal spectacle, no people.` |
| 12 | 8 ث | `POV-like slow descent through the dark well shaft, passing wet limestone rings and hanging roots. Dust and water droplets move past the lens, distant machinery hum implied visually only. No characters, no text.` |
| 13 | 8 ث | `A narrow underground passage revealed by a handheld warm lamp beam moving across scratched stone, flooded floor and forgotten support beams. The camera walks forward steadily, cinematic realistic suspense, no beings.` |
| 14 | 8 ث | `The passage opens onto a vast underground chamber of ancient limestone and oxidised mechanisms. The camera gently rises to reveal scale while keeping the centre dark. No alien figures, no written glyphs, no religious imagery.` |
| 15 | 8 ث | `Close cinematic pass over a non-readable stone star map made of simple geometric inlays and metal calibration marks. A small blue pulse travels across the inlays. Grounded technical artifact, no text, no symbols of faith.` |
| 16 | 8 ث | `A heavy mechanical circular threshold begins rotating within the chamber. Stone teeth, bronze joints and soft cyan light move with believable weight; dust falls from the ceiling. No fantasy explosion or people.` |
| 17 | 8 ث | `Through the opening threshold, a rainy prehistoric valley is glimpsed in the distance. Leaves move in wind and a large animal silhouette crosses far behind fog, never close to camera. Realistic scale and survival mood.` |
| 18 | 8 ث | `A second glimpse through the rotating threshold shows a weathered mud-brick city and ziggurat at sunset. Dust passes across the frame and the distant architecture feels historical and real, no crowds or writing.` |
| 19 | 8 ث | `A third glimpse shows a flooded stone temple and a calibrated ring reflecting blue light in water. Slow camera push toward its centre, no statues, no gods, no people, no text.` |
| 20 | 8 ث | `A dignified abstract time archive: layered anonymous map fragments and city silhouettes glide through a dark architectural tunnel. No faces, no historical or religious characters, no readable labels.` |
| 21 | 8 ث | `A final threshold view opens onto a near-future Mars outpost window. A red dust storm moves outside while a silent engineered core floats in a dark room. Grounded NASA-inspired realism, no astronauts or logos.` |
| 22 | 8 ث | `Return to the underground chamber as all seven threshold rings settle and their light dims to a single cold blue point. Slow pullback through dust and darkness, photorealistic materials, no text.` |
| 23 | 8 ث | `Match the opening courtyard at night. The well is still, the warm lamp is lit, and a faint blue light breathes once beneath the stone before fading. Hold a clean dark lower frame for the game start button; no text or people.` |

## انتقالات الفصول

| المقطع | البرومبت الجاهز |
| --- | --- |
| TRANS-02 | `Slow vertical descent inside an abandoned industrial elevator into an underground records facility. Aged concrete, limestone cuts, brass archive doors, brief amber emergency lights, light steam and dust. Photorealistic, constrained cyan glow, no people, no text, no logos, no UI.` |
| TRANS-03 | `The camera passes through a heavy rotating stone-and-bronze threshold and emerges into a rain-soaked primeval valley. Ferns bend in wind, wet rocks reflect distant gold light, a vast silhouette moves very far behind mist. Continuous 8-second camera move, realistic survival mood, no people, no gore, no cartoon animals.` |
| TRANS-04 | `A low forward glide along a mud-brick avenue toward a realistic ancient ziggurat under a dusty sunset. Water in shallow irrigation channels ripples; cloth banners move far away. Historical atmosphere with no figures, no gods, no readable writing, no text.` |
| TRANS-05 | `A measured slow orbit around a submerged ancient stone passage ring in a dark temple. Water reflects warm lamps, bronze mechanisms turn with realistic weight, restrained cyan core light gathers at the centre. No people, no religious statues, no text, no logos.` |
| TRANS-06 | `A seamless forward travel through an abstract architectural archive of time: anonymous urban strata, blank map fragments and stone arches rearrange around a central walkway. Dignified, non-religious, no faces, no writing, no apocalypse symbols, photorealistic.` |
| TRANS-07 | `A lateral camera glide along a reinforced window inside a realistic Mars research outpost. Red dust storm and crater ridge outside; inside, a silent engineered threshold core hovers above a circular platform. Grounded sci-fi, no astronauts, no robots, no text or logo.` |

## ملاحظة الدمج

يجمع الإنترو في قائمة تشغيل فيديو قصيرة، ويُستخدم `TRANS-02` إلى `TRANS-07` بين تحدي الفصل وانتقال العالم التالي. تظل الصور الأصلية الحالية fallback مرئياً سريعاً للأجهزة أو الشبكات التي لا تسمح بالتشغيل التلقائي للفيديو، ثم تُستبدل بالمقاطع بعد اختبار كل ملف MP4 في المتصفح.
