# Credits and Asset Licenses

## الأصول المستخدمة فعلياً

| الأصل | الاستخدام | الصانع | الترخيص | رابط المصدر | الحجم المرفوع |
|---|---|---|---|---|---:|
| Asphalt 02 — Diffuse 1K | Base Color للأرض | Rob Tuytel | CC0 | https://polyhaven.com/a/asphalt_02 | 731,707 بايت |
| Asphalt 02 — Normal GL 1K | Normal للأرض | Rob Tuytel | CC0 | https://polyhaven.com/a/asphalt_02 | 1,240,122 بايت |
| Asphalt 02 — Roughness 1K | Roughness للأرض | Rob Tuytel | CC0 | https://polyhaven.com/a/asphalt_02 | 544,032 بايت |

## قرارات عدم الاعتماد

| الأصل | الصانع | الترخيص | سبب عدم الاعتماد | الرابط |
|---|---|---|---|---|
| Generic Sedan Car | MMC Works | CC-BY | 113.2 ألف مثلث؛ يتجاوز سقف الأصل المفرد قبل LOD. | https://sketchfab.com/3d-models/generic-sedan-car-58c33766470d46e7b2aed542650494e5 |
| Sedan | hakbux265 | CC-BY | 3.4 ألف مثلث، لكن الهيئة والخامات منخفضة التفاصيل ولا تحقق معيار الواقعية والخامة PBR المطلوب. | https://sketchfab.com/3d-models/sedan-323940f331f9407e827ead8549c98dd2 |

الأبنية والبوابات والسيارة في الإصدار الأول نماذج إجرائية أصلية ذات أحجام ومواد واقعية، إلى أن يوجد GLB مناسب بعد تقييم ترخيصه وخرائطه وحجمه. الأصول المولدة المرتبطة بالمشروع مذكورة في `ASSETS.md` ولا تمثل أصول Sketchfab خارجية.


## توسعات النماذج ثلاثية الأبعاد

| الأصل | الاستخدام | الصانع | الترخيص | رابط المصدر | النسخة المستخدمة |
|---|---|---|---|---|---|
| 2024 Porsche 992 GT3 R | سيارة اختيارية في الفصل الأول | Dave Love SketchFab (`Tyler_Dave`) | CC-BY-4.0 كما هو مضمّن في metadata داخل GLB | https://sketchfab.com/3d-models/2024-porsche-992-gt3-r-b76c9b2ae2d548c3869426eac4ab8a19 | نسخة WebP بخامات فقط، نحو 33.17MB، التخزين: `/manus-storage/2024_porsche_992_gt3_r_texture_only_de531f2d.glb` |
| Woman Standing V8 | مظهر روز الاختياري | Fadly.W | CC-BY-4.0 كما هو مضمّن في metadata داخل GLB | https://sketchfab.com/3d-models/woman-standing-v8-0ca28ee485b1482c883f78b260edf0c8 | `/manus-storage/woman_standing_v8_97e56816.glb` |

يجب إبقاء نسب CC-BY هذه في أي توزيع عام. النسخ المضغوطة لا تغيّر صاحب العمل الأصلي ولا تلغي شروط الترخيص. صورة الراوي المقدمة من المستخدم ليست مضافة هنا كمصدر خارجي مستقل لأن صاحب حقوقها لم يُثبت في الرسالة؛ يلزم تأكيد ذلك قبل نشرها خارج مساحة المشروع.
